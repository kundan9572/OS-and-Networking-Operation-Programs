/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

#include<omp.h>

int fib(int n)
{
    if(n<2)
        return n;
    else 
        return fib(n-1)+fib(n-2);
}

int main()
{
    int fibnum[10],n,i,j;
    printf(" enter the series limit \n");
    scannf("%d",&n);
    
    #pragma omp parallel num_threads(2) shared(fibnum,n) private(i,j)
    
    {
        if(omp_get_thread-num()==0)
        {
            printf(" there are %d threads\n",omp_get_num_threads());
            printf("thread %d are generating number\n",omp_get_thread_num());
            for(i=0;i<n;i++)
                fibnum[i]=fib(i);
        }
    #pragma omp barrier
    if(omp_get_thread_num() !=0)
    {
        printf("thread %d are printing number\n",omp_get_thread_num());
        for(j=0;j<n;j++)
            printf("%d\n",fib(j));
    }
    }
    return 0;
}