set ns [ new Simulator ]
set trf [ open 3.tr w ]
$ns trace-all $trf
set namf [ open 3.nam w ]
$ns namtrace-all $namf

set n0 [ $ns node ]
set n1 [ $ns node ]
set n2 [ $ns node ]
set n3 [ $ns node ]

$ns color 1 "red"
$ns color 2 "blue"

$n0 label "Source/FTP"
$n1 label "Source/Telnet"
$n2 label "Router"
$n3 label "Destination/FTP/Telnet"

$ns duplex-link $n0 $n2 5Mb 10ms DropTail
$ns duplex-link $n1 $n2 10Mb 10ms DropTail
$ns duplex-link $n2 $n3 15Mb 10ms DropTail

set tcp0 [new Agent/TCP]
$ns attach-agent $n0 $tcp0
set ftp0 [new Application/FTP]
$ftp0 attach-agent $tcp0
set sink4 [new Agent/TCPSink]
$ns attach-agent $n3 $sink4

set tcp1 [ new Agent/TCP]
$ns attach-agent $n1 $tcp1
set telnet1 [ new Application/Telnet ]
$telnet1 attach-agent $tcp1
set sink3 [new Agent/TCPSink]
$ns attach-agent $n3 $sink3

$ftp0 set packetSize_ 500Mb
$ftp0 set interval_ 0.01
$telnet1 set packetSize_ 500Mb
$telnet1 set interval_ 0.001

$tcp0 set class_ 1
$tcp1 set class_ 2

$ns connect $tcp0 $sink4
$ns connect $tcp1 $sink3

proc finish {} {
	global ns namf trf
	$ns flush-trace
	exec nam 3.nam &
	close $trf
	close $namf
	exit 0
}

$ns at 0.3 "$ftp0 start"
$ns at 0.3 "$telnet1 start"
$ns at 10.0 "finish"
$ns run
