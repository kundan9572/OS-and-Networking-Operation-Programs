/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int c=0,c1,c2[20],f,i,j,k=0,n,r,temp;
    int p[20],q[20],b[20];
    printf(" enter the no of pages \n");
    scanf("%d",&n);
    printf(" enter the references strings\n");
    for(i=0;i<n;i++)
    {
        scanf("%d",&p[i]);
    }
    printf(" enter the no. of frames\n");
    scanf("%d",&f);
    
    q[k]=p[k];
        printf("\n\t%d\n",q[k]);
    c++;
    k++;
    for(i=1;i<n;i++)
    {
        c1=0;
        for(j=0;j<f;j++)
        {
            if(p[i] !=q[j])
            c1++;
        }
        if(c1==f)
        {
            c++;
            if(k<f)
            {
                q[k]=p[i];
                k++ ;
            }
            for(j=0;j<k;j++)
                printf("\t%d",q[j]);
                printf("\n");
        }
        else
        {
            for(r=0;r<f;r++)
            {
                c2[r]=0;
                for(j=i-1;j<n;j--)
                {
                    if(q[r] !=p[j])
                    c2[r]++;
                    
                    else 
                        break;
                }
            }
            for(r=0;r<f;r++)
                b[r]=c2[r];
            for(r=0;r<f;r++)
            {
                for(j=r;j<f;j++)
                {
                    if(b[r]<b[j])
                    {
                        temp=b[r];
                        b[r]=b[j];
                        b[j]=temp;
                    }
                }
            }
            for(r=0;r<f;r++)
            {
                if(c2[r]==b[0])
                {
                    q[r]=p[i];
                    printf("\t %d",q[r]);
                }
                printf("\n");
            }
        }
    }
    printf(" total page fault is : %d\n",c);
}