/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
  int p[10],b[10],w[10],t[10];
  int i,j,n,temp,temp1;
  float awt=0,att=0;
  printf("enter the no of process\n");
  scanf("%d",&n);
  for(i=0;i<n;i++)
  {
      printf("enter the burst time for process:%d\n",i+1);
      scanf("%d",&b[i]);
      p[i]=i+1;
  }
  for(i=0;i<n;i++)
  for(j=i;j<n;j++)
  {
      if(b[i]>b[j])
      {
          temp=b[i];
          temp1=p[i];
          b[i]=b[j];
          p[i]=p[j];
          b[j]=temp;
          p[j]=temp1;
      }
  }
   w[0]=0;
    for(i=1;i<n;i++)
    {
        w[i]=w[i-1]+b[i-1];
    }
    for(i=0;i<n;i++)
    {
        t[i]=w[i]+b[i];
    }
    for(i=0;i<n;i++)
    {
        awt +=w[i];
        att +=t[i];
    }
    printf("\t process \t waiting time \t turnaround time\n");
    for(i=0;i<n;i++)
    printf("\n\t\t%d\t\t%d\t\t%d\n",p[i],w[i],t[i]);
    printf(" total waiting time is:%f\n",awt);
    awt /=n;
    printf(" avg waiting time is:%f\n",awt);
    printf("\n");
    
    printf(" total turnaround time is :%f\n",att);
    att /=n;
    printf(" avg turnaround time is:%f\n",att);
  
}
