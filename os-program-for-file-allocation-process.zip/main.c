/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int f[100],i,a,p,st,len,ch,k,j,n;
    for(i=0;i<50;i++)
        f[i]=0;
    printf("\n enter the no. of block allocated\n");
    scanf("%d",&p);
    printf(" enter the allocated block\n");
    for(i=0;i<p;i++)
    {
        scanf("%d",&a);
        f[a]=1;
    }
    x:
    printf("\n enter the index of starting block and length\n");
    scanf("%d%d",&st,&len);
    k=len;
    if(f[st]==0)
    {
        for(j=st;j<(k+st);j++)
        {
            if(f[j]==0)
            {
                f[j]=1;
                printf("\t%d--->%d\n",j,f[j]);
            }
            else
            {
                printf(" %d---> file is already allocated\n",j);
                k++;
            }
        }
    }
    else
    {
        printf(" enter 1 to continue or 0 to exit\n");
        scanf("%d",&ch);
        if(ch==1)
            goto x;
        else 
            exit(0);
    }
}
