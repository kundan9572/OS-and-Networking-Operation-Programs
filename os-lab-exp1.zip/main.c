/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include<unistd.h>
main()
{
    int pid,ch;
    char cmd[10];
    pid=fork();
    if(pid==0)
    {
        printf("\n child process \n");
        do
        {
            printf(" enter the command\n");
            scanf("%s",&cmd);
            system(cmd);
            printf(" enter 1 to continue or 0 to exit \n");
            scanf("%d",&ch);
            
        }
        while( ch!=0);
    }
    else
        wait();
}