/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
main()
{
    int tot,m,s[10],n,i,ch,p=0;
    
    printf("enter the size of primary memory \n");
    scanf("%d",&tot);
    printf(" enter the size of os \n");
    scanf("%d",&m);
    tot=tot-m;
    while(1)
    {
        printf("enter the no. of pages for process %d:\n",p+1);
        scanf("%d",&n);
        for(i=0;i<n;i++)
        {
            printf(" eneter the size of pages for process %d\n",i+1);
            scanf("%d",&s[i]);
            
        }
        for(i=0;i<n;i++)
        {
         if(tot >=s[i])
        {
            printf("allocated page is %d\n",i+1);
            tot=tot-s[i];
        }
        else
        {
            printf("%d page is blocked\n",i+1);
    
        }
    }
    printf(" press 1 to continue and 0 to exit\n");
    scanf("%d",&ch);
    if( ch==0)
        break;
    p++;
}
printf(" external fragmentation is %d\n",tot);
}
