/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include<stdlib.h>
void disp();

struct frame
{
    int page;
    int counter;
}frm[10];

int f;

int main()
{
    int i,j;
    int str[50],n;
    int fault=0,index;
    
    printf("enter the no of pages in references string\n");
    scanf("%d",&n);
    
    printf(" enter the references string\n");
    for(i=0;i<n;i++)
        scanf("%d",&str[i]);
    printf("enter the np. of frames\n");
    scanf("%d",&f);
    
    for(i=0;i<f;i++)
    {
        frm[i].page=-1;
        frm[i].counter=(f-i)*20;
    }
    printf("\n");
    for(i=0;i<n;i++)
    {
        index=0;
        for(j=0;j<f;j++)
        {
            if(str[i]==frm[j].page)
            {
                frm[j].counter=0;
                break;
            }
            if(frm[j].counter > frm[index].counter)
            
            index=j;
        }
        if(j==f)
        {
            frm[index].page=str[i];
            frm[index].counter=0;
            fault ++;
            disp();
            
        }
        for(j=0;j<f;j++)
                
                frm[j].counter++;
                
    }
    printf("there are total %d page fault\n",fault);
    return 0;
}

void disp()
{
    int i;
    for(i=0;i<f;i++)
    if(frm[i].page !=-1)
        printf("%d\t",frm[i].page);
    printf("\n");
}