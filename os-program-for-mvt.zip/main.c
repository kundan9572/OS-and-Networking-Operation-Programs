/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int s[10],tot,m,ch,i,n,p=0;
    printf("enter the size of memory\n");
    scanf("%d",&tot);
    printf(" enter size of os\n");
    scanf("%d",&m);
    tot=tot-m;
    while(1)
    {
        printf("enter the no of pages for process %d\n",p);
        scanf("%d",&n);
        for(i=0;i<n;i++)
        {
            printf(" enter size of pages of process %d\n",i+1);
            scanf("%d",&s[i]);
            
        }
    
        for(i=0;i<n;i++)
        {
            if(tot >= s[i])
            {
                printf(" allocated file is:%d\n",i+1);
                tot=tot-s[i];
            }
            else
                printf(" process p%d is blocked\n",i+1);
        }
        printf("enter 1 to continue or 0 to exit\n");
        scanf("%d",&ch);
        if(ch==0)
            break;
        p++;
        
    }
    printf(" external gragmentation is: %d\n",tot);
}
